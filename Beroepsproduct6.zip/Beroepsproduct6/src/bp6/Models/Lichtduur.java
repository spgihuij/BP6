package bp6.Models;

public class Lichtduur {
}

package bp6.Models;

import java.util.Date;

public class Beweging {
    private Date tijd;

    public Beweging(Date tijd, String id){

    }

    public Date getTijd() {
        return tijd;
    }

    public void setTijd(Date tijd) {
        this.tijd = tijd;
    }
}
